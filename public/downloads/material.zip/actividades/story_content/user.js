function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5cgjDA7H9ca":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

